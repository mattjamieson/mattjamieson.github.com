package uk.co.newsbot.formatters;

public enum ItemFormat
{
	DEFAULT,
	IRC
}